
import React from 'react'
export default function Stats(){
  return <div className="token-card" style={{padding:'1rem'}}>Estatísticas (em breve: gráficos de coleção por plataforma/estado/ano)</div>
}
