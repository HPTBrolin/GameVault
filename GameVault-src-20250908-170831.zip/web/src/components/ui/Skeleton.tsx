
import React from 'react'
export function SkeletonCard(){ return <div className="sk-card token-card"><div className="bar"/><div className="l1"/><div className="l2"/></div> }
