// Add near the right side of topbar:
import SyncBadge from "./components/SyncBadge";

// ... inside the topbar's right side container (before settings button):
<SyncBadge />
